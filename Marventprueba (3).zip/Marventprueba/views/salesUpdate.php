<!DOCTYPE html>
<html lang="es">
<?php
session_start();
if (!$_SESSION['UsuEmail']) {
  header('location:../views/login.php');
}
?>

<head>
    <!--METADATOS-->
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="GESTION DE INVENTARIO DE MINIMERCADOS">
    <meta name="keywords" content="durabilidad, facilidad, inventario">
    <!--TITULO-->
    <title>VENTAS</title>
    <!--favicon-->
    <link rel="icon" href="../resources/imagenes/logo.png">
    <!--LINKS-->
    <link rel="stylesheet" href="../resources/css/SalUp.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
    <!--LINK DE ICONOS-->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">

</head>

<body>
    <!--BARRA DE ARIBA-->
    <header>
        <nav class="navbar navbar-expand-md navbar-light">
            <div class="container nav">

                <div class="col ">
                    <img class="nav-link" src="../resources/imagenes/logo pero negro.png" alt="">


                </div>

                <div class="col ">
                    <h1 class="text-cenetr">VENTAS</h1>


                </div>

                <div class="col  ">
                    <form class="d-flex">
                        <button class="btn btn-light" type="button" data-bs-toggle="modal"
                            data-bs-target="#staticBackdrop"><svg xmlns="http://www.w3.org/2000/svg" width="16"
                                height="16" fill="currentColor" class="bi bi-box-arrow-left" viewBox="0 0 16 16">
                                <path fill-rule="evenodd"
                                    d="M6 12.5a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v2a.5.5 0 0 1-1 0v-2A1.5 1.5 0 0 1 6.5 2h8A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 5 12.5v-2a.5.5 0 0 1 1 0v2z">
                                </path>
                                <path fill-rule="evenodd"
                                    d="M.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L1.707 7.5H10.5a.5.5 0 0 1 0 1H1.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3z">
                                </path>
                            </svg></button>
                    </form>




                </div>


            </div>
        </nav>
    </header>
    <div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
        aria-labelledby="staticBackdropLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h1 class="modal-title fs-5" id="staticBackdropLabel">CERRAR SESIÓN </h1>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    ¿Seguro que desea cerrar session?
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-dark" data-bs-dismiss="modal">ATRAS</button>
                    <a href="../controllers/closeSession.php"><button type="button"
                            class="btn btn-warning">CERRAR</button></a>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    <br>
    <br>
    <br>
    <br>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm"></div>
            <div class="col-sm text-center">
                <h2>DATOS DEL CLIENTE</h2>
                <hr>
                <p>Por favor ingrese el numero de documento del cliente. </p>
                <br>
            </div>
            <div class="col-sm"></div>
        </div>
        <div class="row">
            <div class="col-sm"></div>
            <div class="col-sm text-center">
                <div class="mb-3">
                    <label for="exampleInputEmail1" class="form-label">Cedula de Ciudadania</label>
                    <input type="number" name="doc" class="form-control" id="doc">
                    <br>
                    <button class="btn btn-dark" onclick="BuscarUser()">Buscar</button>
                    <a href="sales.php" class="btn btn-dark">Regresar</a>
                </div>
            </div>
            <div class="col-sm"></div>
        </div>
        <div class="container bg-warning text-center" id="info-message" style="display: none;">
            <h3> <i class="bi bi-exclamation-triangle-fill"></i>Atención.</h3>
            <hr>
            <p>El campo documento esta vacio.</p>
            <br>
        </div>
        <br>
        <div class="container">
            <div class="row" style="background-color: #F4EBDF;">
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Nombre y Apellido</label>
                        <input type="text" name="nombre" class="form-control" id="nombre" readonly>

                    </div>
                </div>
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Telefono personal</label>
                        <input type="text" name="tel" class="form-control" id="tel" readonly>

                    </div>
                </div>
            </div>
            <div class="row" style="background-color: #F4EBDF;">
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Dirreción</label>
                        <input type="text" name="ClieDireccion" id="CLieDireccion" class="form-control" readonly>

                    </div>
                </div>
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <label for="exampleInputEmail1" class="form-label">Correo</label>
                        <input ttype="text" name="ClieEmailPersonal" id="ClieEmailPersonal" class="form-control"
                            id="exampleInputEmail1" readonly>
                    </div>
                </div>
            </div>
        </div>

    </div>
    <br>
    <br>
    <div class="">
        <div class="container py-4 text-center">
            <div class="row g-4">
                <div class="col-auto">
                    <label for="num_registros" class="col-form-label">Mostrar: </label>
                </div>
                <div class="col-auto">
                    <select name="num_registros" id="num_registros" class="form-select">
                        <option value="5">5</option>
                        <option value="10">10</option>
                        <option value="25">25</option>
                        <option value="50">50</option>
                        <option value="100">100</option>
                    </select>
                </div>
                <div class="col-auto">
                    <label for="num_registros" class="col-form-label">registros </label>
                </div>
                <div class="col-5"></div>
                <div class="col-auto">
                    <label for="campo" class="col-form-label">Buscar: </label>
                </div>
                <div class="col-auto">
                    <input type="text" name="campo" id="campo" class="form-control">
                </div>
            </div>
            <div class="row py-4">
                <div class="col">
                    <table class="table table-s table-bordered table-striped">
                        <thead>
                            <th class="sort asc">Id_producto</th>
                            <th class="sort asc">Producto</th>
                            <th class="sort asc">Precio</th>
                            <th class="sort asc">Marca</th>
                            <th class="sort asc">Fecha Expedicion</th>
                            <th class="sort asc">Cantidad</th>
                        </thead>
                        <!-- El id del cuerpo de la tabla. -->
                        <tbody id="content">
                        </tbody>
                    </table>
                </div>
            </div>
            <br>
            <br>  
            <br>
            <div class="row">
                <div class="col-6">
                    <label id="lbl-total"></label>
                </div>
                <div class="col-6" id="nav-paginacion"></div>
                <input type="hidden" id="pagina" value="1">
                <input type="hidden" id="orderCol" value="0">
                <input type="hidden" id="orderType" value="asc">
            </div>
        </div>
        </main>
        <script>
        /* Llamando a la función getData() */
        getData()
        /* Escuchar un evento keyup en el campo de entrada y luego llamar a la función getData. */
        document.getElementById("campo").addEventListener("keyup", function() {
            getData()
        }, false)
        document.getElementById("num_registros").addEventListener("change", function() {
            getData()
        }, false)
        /* Peticion AJAX */
        function getData() {
            let input = document.getElementById("campo").value
            let num_registros = document.getElementById("num_registros").value
            let content = document.getElementById("content")
            let pagina = document.getElementById("pagina").value
            let orderCol = document.getElementById("orderCol").value
            let orderType = document.getElementById("orderType").value
            if (pagina == null) {
                pagina = 1
            }
            let url = "../controllers/loadventprod.php"
            let formaData = new FormData()
            formaData.append('campo', input)
            formaData.append('registros', num_registros)
            formaData.append('pagina', pagina)
            formaData.append('orderCol', orderCol)
            formaData.append('orderType', orderType)
            fetch(url, {
                    method: "POST",
                    body: formaData
                }).then(response => response.json())
                .then(data => {
                    content.innerHTML = data.data
                    document.getElementById("lbl-total").innerHTML = 'Mostrando ' + data.totalFiltro +
                        ' de ' + data.totalRegistros + ' registros'
                    document.getElementById("nav-paginacion").innerHTML = data.paginacion
                }).catch(err => console.log(err))
        }

        function nextPage(pagina) {
            document.getElementById('pagina').value = pagina
            getData()
        }
        let columns = document.getElementsByClassName("sort")
        let tamanio = columns.length
        for (let i = 0; i < tamanio; i++) {
            columns[i].addEventListener("click", ordenar)
        }

        function ordenar(e) {
            let elemento = e.target
            document.getElementById('orderCol').value = elemento.cellIndex
            if (elemento.classList.contains("asc")) {
                document.getElementById("orderType").value = "asc"
                elemento.classList.remove("asc")
                elemento.classList.add("desc")
            } else {
                document.getElementById("orderType").value = "desc"
                elemento.classList.remove("desc")
                elemento.classList.add("asc")
            }
            getData()
        }
        </script>
    </div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-sm">
            </div>
            <div class="col-sm text-center">
                <h2>Detalle Factura</h2>
                <hr>
            </div>
            <div class="col-sm">
            </div>
        </div>
        <div class="container" style="background-color: #F4EBDF;">
            <div class="row">
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <input type="number" name="cod" id="cod" class="form-control "
                            placeholder="Codigo del Producto">

                    </div>
                </div>
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <input type="text" name="prod" id="prod" class="form-control" placeholder="Nombre del Producto">

                    </div>
                </div>
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <input type="number" name="precio" id="precio" class="form-control"
                            placeholder="Precio unitario">
                    </div>
                </div>
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <input type="text" name="marca" id="marca" class="form-control" placeholder="Marca producto">
                    </div>
                </div>
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <input type="text" name="fecha" id="fecha" class="form-control" placeholder="Fecha expiración">
                    </div>
                </div>
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <input type="number" name="ciudad" id="ciudad" class="form-control"
                            placeholder="Cantidad en unidades">
                    </div>
                </div>
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <button class="btn btn-dark" onclick="AgregarFact()"><i
                                class="bi bi-plus-circle"></i>Agregar</button>
                    </div>
                </div>
                <!--
                <div class="col-sm">
                    <br>
                    <div class="mb-3">
                        <button class="btn btn-dark" onclick="BuscarFact()"><i class="bi bi-search"></i>buscar</button>
                    </div>
                </div>
                -->
            </div>
            <br>
        </div>
        <br>
        <div class="container">
            <div class="row">
                <div class="col-sm-2"></div>
                <div class="col-sm-8 text-center">
                    <table id="tablevent" class="table table-hover">
                        <thead>
                            <tr>
                                <th>
                                    Codigo
                                </th>
                                <th>
                                    Nombre
                                </th>
                                <th>
                                Cantidad U/N
                                </th>
                                <th>
                                    Marca
                                </th>
                                <th>
                                    Fecha Expiración
                                </th>
                                <th>
                                    precio
                                </th>
                            </tr>
                        </thead>
                        <tbody id="cuerpo-tabla">

                        </tbody>
                        <tfoot>
                            <tr>
                                <td colspan="5">Suma Total</td>
                                <td id="idTotal"></td>
                            </tr>
                        </tfoot>
                    </table>
                    <div>
                     <button class="btn btn-dark">Hacer Venta</button>
                    </div>
                    <br>
                </div>
                <div class="col-sm-2"></div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-geWF76RCwLtnZ8qwWowPQNguL3RmwHVBC9FhGdlKrxdiJJigb/j/68SIy3Te4Bkz" crossorigin="anonymous">
    </script>
    <script src="https://code.jquery.com/jquery-3.7.0.js"
        integrity="sha256-JlqSTELeR4TLqP0OG9dxM7yDPqX1ox/HfgiSLBj8+kM=" crossorigin="anonymous"></script>


</body>
<footer class="row" id="row-pie">
        <div class="container">
            <div class="row">
                <div class=" col grupo2 text-center">
                    <a href="https://www.facebook.com/"><img src="../resources/imagenes/icono-facebook.png"
                            alt="Facebook"></a>
                    <a href="https://www.instagram.com/"><img src="../resources/imagenes/icono-instagram.png"
                            alt="Instagram"></a>
                    <a href="https://twitter.com/"><img src="../resources/imagenes/tiwitter-icono.png"
                            alt="Twitter"></a>
                </div>
            </div>
        </div>
        <div class="pie-bajo">
            <p class="text-center"> &copy; 2023 Copyright <a href="#row-contacto">Generado por: MARVENT</a> </p>
        </div>
    </footer>
<script>
function BuscarUser() {
    let documento = $('#doc').val();
    if (documento) {
        $('#info-message').hide('400');
        consultarUser(documento);
    } else {
        $('#info-message').show('400');
        return false;
    }
}


function consultarUser(documento) {

    $.ajax({
        // la URL para la petición
        url: '../controllers/consultarUser.php?doc=' + documento,

        // la información a enviar
        // (también es posible utilizar una cadena de datos)
        data: {},

        // especifica si será una petición POST o GET
        type: 'GET',

        // el tipo de información que se espera de respuesta
        dataType: 'json',

        // código a ejecutar si la petición es satisfactoria;
        // la respuesta es pasada como argumento a la función
        success: function(json) {
            $('#nombre').val(json['2']);
            $('#tel').val(json['3']);
            $('#CLieDireccion').val(json['4']);
            $('#ClieEmailPersonal').val(json['5']);
        },

        // código a ejecutar si la petición falla;
        // son pasados como argumentos a la función
        // el objeto de la petición en crudo y código de estatus de la petición
        error: function(xhr, status) {
            alert('Disculpe, existió un problema');
        },

        // código a ejecutar sin importar si la petición falló o no
        complete: function(xhr, status) {
            //alert('Petición realizada');
        }
    });
}

function AgregarFact() {

    let codP = $('#cod').val();
    let nombreP = $('#prod').val();
    let precioP = $('#precio').val();
    let marcaP = $('#marca').val();
    let fechaP = $('#fecha').val();
    let ciudadP = $('#ciudad').val();

    if (codP == '' || codP == undefined || codP == null) {
        alert('Campo vacio');
        return false;
    }
    if (nombreP == '' || nombreP == undefined || nombreP == null) {
        alert('Campo vacio');
        return false;
    }

    if (precioP == '' || precioP == undefined || precioP == null) {
        alert('Campo vacio');
        return false;
    }

    if (marcaP == '' || marcaP == undefined || marcaP == null) {
        alert('Campo vacio');
        return false;
    }

    if (fechaP == '' || fechaP == undefined || fechaP == null) {
        alert('Campo vacio');
        return false;
    }


    if (ciudadP == '' || ciudadP == undefined || ciudadP == null) {
        alert('Campo vacio');
        return false;
    }
    let html = "<tr><td>" + codP + "</td><td>" + nombreP + "</td><td>" + ciudadP + "</td><td>" + marcaP + "</td><td>" +
        fechaP + "</td><td>" + precioP + "</td></tr>";

    $('#cuerpo-tabla').append(html);
    sumCantidad();

    let total1 = 0;
    const table = document.getElementById("tablevent");
    for (let i = 1; i < table.rows.length - 1; i++) {
        let rowValue = table.rows[i].cells[2].innerHTML;
        total1 = total1 + Number(rowValue);
    }
    function consultarUser(total, total1, codP);

}
function sumCantidad() {
    let total = 0;
    const table = document.getElementById("tablevent");
    for (let i = 1; i < table.rows.length - 1; i++) {
        let rowValue = table.rows[i].cells[5].innerHTML;
        total = total + Number(rowValue);
    }
    const tdTotal = document.getElementById("idTotal");
    tdTotal.textContent = total;
}


function HacerVenta(total, total1, codP) {

$.ajax({
    // la URL para la petición
    url: '../controllers/subiventa.php?doc=' + documento,

    // la información a enviar
    // (también es posible utilizar una cadena de datos)
    data: {},

    // especifica si será una petición POST o GET
    type: 'GET',

    // el tipo de información que se espera de respuesta
    dataType: 'json',

    // código a ejecutar si la petición es satisfactoria;
    // la respuesta es pasada como argumento a la función
    success: function(json) {
        $('#nombre').val(json['2']);
        $('#tel').val(json['3']);
        $('#CLieDireccion').val(json['4']);
        $('#ClieEmailPersonal').val(json['5']);
    },

    // código a ejecutar si la petición falla;
    // son pasados como argumentos a la función
    // el objeto de la petición en crudo y código de estatus de la petición
    error: function(xhr, status) {
        alert('Disculpe, existió un problema');
    },

    // código a ejecutar sin importar si la petición falló o no
    complete: function(xhr, status) {
        //alert('Petición realizada');
    }
});
}
// buscar producto
/*
function BuscarFact() {
    let codP = $('#cod').val();
    if (codP) {
        $('#info-message').hide('400');
        consultarProd(codP);
    } else {
        $('#info-message').show('400');
        return false;
    }
}


function consultarProd(codP) {

    $.ajax({
        // la URL para la petición
        url: '../controllers/consultarProd.php?cod=' + codP,

        // la información a enviar
        // (también es posible utilizar una cadena de datos)
        data: {},

        // especifica si será una petición POST o GET
        type: 'GET',

        // el tipo de información que se espera de respuesta
        dataType: 'json',

        // código a ejecutar si la petición es satisfactoria;
        // la respuesta es pasada como argumento a la función
        success: function(json) {
          var prod =  $('#prod').val(json['1']);
            $('#precio').val(json['2']);
            $('#marca').val(json['3']);
            $('#fecha').val(json['4']);
            $('#ciudad').val(json['5']);
        },

        // código a ejecutar si la petición falla;
        // son pasados como argumentos a la función
        // el objeto de la petición en crudo y código de estatus de la petición
        error: function(xhr, status) {
            alert('Disculpe, existió un problema');
        },

        // código a ejecutar sin importar si la petición falló o no
        complete: function(xhr, status) {
            //alert('Petición realizada');
        }
    });
}
*/
</script>

</HTml>