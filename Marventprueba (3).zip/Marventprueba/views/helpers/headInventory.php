<head>
  <!--METADATOS-->
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="GESTION DE INVENTARIO DE MINIMERCADOS">
  <meta name="keywords" content="durabilidad, facilidad, inventario">
  <!--TITULO-->
  <title>Inventario</title>
  <!--favicon-->
  <link rel="icon" href="../resources/imagenes/logo.png">
  <!--LINKS-->
  <link rel="stylesheet" href="../resources/css/style1.css?V=1.4">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/css/bootstrap.min.css" rel="stylesheet" 
    integrity="sha384-aFq/bzH65dt+w6FI2ooMVUpc+21e0SRygnTpmBvdBgSdnuTN7QbdgL+OapgHtvPp" crossorigin="anonymous">
  <!--LINK DE ICONOS-->
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.10.4/font/bootstrap-icons.css">
  <!--LINKS DE TABLAS-->
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/5.2.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.13.4/css/dataTables.bootstrap5.min.css">
