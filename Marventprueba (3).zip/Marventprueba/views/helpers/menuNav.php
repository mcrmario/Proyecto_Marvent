<nav>
    <div>
        <img src="resources/imagenes/logoynombre.png" alt="logo de la compañia">
    </div>
    <div>
        <a href="#inicio">Inicio</a>
        <a href="#acercade">Acerca De</a>
        <a href="#modulos">Modulos</a>
        <a href="#funciones">Funcionalidad</a>
        <a href="#ventajas">Ventaja</a>
        <a href="#contacto">Contacto</a>
        <a href="views/login.php"><button>iniciar sesión</button></a>

    </div>
</nav>