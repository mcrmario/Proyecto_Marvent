<!DOCTYPE html>
<html lang="es">
<?php
session_start();
include '../views/helpers/headInventory.php';
include '../models/home.php';
?>
<!--BARRA DE ARIBA-->
<header>
    <nav class="navbar navbar-expand-md navbar-light">
        <div class="container nav">

            <div class="col ">
                <img class="nav-link" src="../resources/imagenes/logo pero negro.png" alt="">


            </div>

            <div class="col ">
                <h1 class="text-cenetr">INVENTARIO</h1>


            </div>

            <div class="col  ">
                <form class="d-flex">
                    <button class="btn btn-light" type="button" data-bs-toggle="modal"
                        data-bs-target="#staticBackdrop"><svg xmlns="http://www.w3.org/2000/svg" width="16" height="16"
                            fill="currentColor" class="bi bi-box-arrow-left" viewBox="0 0 16 16">
                            <path fill-rule="evenodd"
                                d="M6 12.5a.5.5 0 0 0 .5.5h8a.5.5 0 0 0 .5-.5v-9a.5.5 0 0 0-.5-.5h-8a.5.5 0 0 0-.5.5v2a.5.5 0 0 1-1 0v-2A1.5 1.5 0 0 1 6.5 2h8A1.5 1.5 0 0 1 16 3.5v9a1.5 1.5 0 0 1-1.5 1.5h-8A1.5 1.5 0 0 1 5 12.5v-2a.5.5 0 0 1 1 0v2z">
                            </path>
                            <path fill-rule="evenodd"
                                d="M.146 8.354a.5.5 0 0 1 0-.708l3-3a.5.5 0 1 1 .708.708L1.707 7.5H10.5a.5.5 0 0 1 0 1H1.707l2.147 2.146a.5.5 0 0 1-.708.708l-3-3z">
                            </path>
                        </svg></button>
                </form>




            </div>


        </div>
    </nav>
</header>
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1"
    aria-labelledby="staticBackdropLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h1 class="modal-title fs-5" id="staticBackdropLabel">CERRAR SESIÓN </h1>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                ¿Seguro que desea cerrar session?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-dark" data-bs-dismiss="modal">ATRAS</button>
                <a href="../controllers/closeSession.php"><button type="button"
                        class="btn btn-warning">CERRAR</button></a>
            </div>
        </div>
    </div>
</div>
</div>
</div>

<section class="container-fluid">
    <div class="row">
        <!--BARRA DE NAVEGACION-->
        <nav class="d-flex col-xxl-12 col-xl-12 col-md-12 edit5 ">
            <h5 class="modal-title" id="exampleModalLabel">Agregar Productos</h5>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>

            <div class="modal-body text-lg-center ingresar">
                <form action="../controllers/editar.php" method="POST">
                    <p>Nombre Del Producto</p>

                    <?php

          $id = $_GET['id'];

          include '../models/home.php';

          $sql = "SELECT * from producto where idProducto=$id";

          $resFiltro = $conn->query($sql);
          $row_filtro = $resFiltro->fetch_array();
          ?>

                    <input type="hidden" name="Id" value="<?php echo $row_filtro['IdProducto']; ?>">
                    <input type="text" name="NombreProducto" required placeholder="Nombre"
                        value="<?php echo $row_filtro['ProdNombreProducto'] ?>">
                    <p>Precio Del producto</p>
                    <input type="number" name="PrecioProducto" required placeholder="Precio"
                        value="<?php echo $row_filtro['ProdPrecio'] ?>">
                    <p>Marca Del Producto</p>
                    <input type="text" name="MarcaProducto" required placeholder="Marca"
                        value="<?php echo $row_filtro['ProdMarca'] ?>">
                    <p>Fecha Expedicion del producto</p>
                    <input type="text" name="FechaProducto" required placeholder="Año-Mes-Dia"
                        value="<?php echo $row_filtro['ProdFechaExpedicion'] ?>">
                    <p>Cantidad Del Producto</p>
                    <input type="number" name="CantidadProducto" required placeholder="Cantidad"
                        value="<?php echo $row_filtro['ProdCantidad'] ?>">
            </div>
            <div class="modal-footer">
                <a href="inventory.php"><button type="button" class="btn btn-secondary"
                        data-bs-dismiss="modal">Cancelar</button></a>
                <button type="submit" name="enviar" class="btn btn-primary">Actualizar</button>

            </div>
            </form>
    </div>
    </div>
</section>

<footer class="container-fluid">
    <div class="grupo1 ">
        <img src="../resources/imagenes/logo pero negro.png" alt="icono llamar">
    </div>
    <div class="grupo2 ">
        <a href="https://www.facebook.com"><img src="../resources/imagenes/icono-instagram.png"
                alt="icono de instagram"></a>
        <a href="https://www.instagram.com"><img src="../resources/imagenes/icono-facebook.png"
                alt="icono de icono-facebook"></a>
        <a href="https://twitter.com/twitter"><img src="../resources/imagenes/tiwitter-icono.png"
                alt="icono de tiwtter"></a>
    </div>
</footer>

</body>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha2/dist/js/bootstrap.bundle.min.js"
    integrity="sha384-qKXV1j0HvMUeCBQ+QVp7JcfGl760yU08IQ+GpUo5hlbpg51QRiuqHAJz8+BrxE/N" crossorigin="anonymous">
</script>