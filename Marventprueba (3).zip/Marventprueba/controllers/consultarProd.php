<?php
include("../models/home.php");

$producto=$_GET['cod'];

$sql="SELECT * FROM producto WHERE IdProducto = $producto";
$resFiltro = $conn->query($sql);
$row_filtro = $resFiltro->fetch_array();
$totalFiltro = $row_filtro;

if($totalFiltro){
    echo json_encode($totalFiltro);
}else{
    echo json_encode(0);
}



?>