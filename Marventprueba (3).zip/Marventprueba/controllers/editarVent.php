<?php
/*
 include_once ("../models/home.php");
 $id= $_POST['Id'];
 $PTotal= $_POST['PrecioTotal'];
 $CTotal= $_POST['CantidadTotal'];
 $ClieNombre= $_POST['ClieNombre'];
 $UsuNombre= $_POST['UsuNombre'];

 $sql  = "UPDATE ventas SET 
                PrecioTotal='".$."'
 "
*/
?>